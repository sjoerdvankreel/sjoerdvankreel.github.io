#include <mmdeviceapi.h>
#include <Audioclient.h>
#include <atlbase.h>
#include <iostream>
#include <cstdlib>
#include <cassert>
#include <fstream>
#include <cstring>

static const int HNS_PER_MS = 10000;
static const int BUFFER_SIZE_MS = 10;
static const int BUFFER_SIZE_HNS = BUFFER_SIZE_MS * HNS_PER_MS;

static const int CHANNELS = 2;
static const int MAX_RECORD_SECONDS = 5;
static const int SAMPLE_RATE = 48000;
static const auto AUDIO_CLIENT_SCREWED_UP = AUDCLNT_E_UNSUPPORTED_FORMAT;
static float RECORDING[SAMPLE_RATE * CHANNELS * MAX_RECORD_SECONDS];

static int RunOne(int current);

#define VERIFY(hr) if(FAILED(hr)) {  \
  if(hr == AUDIO_CLIENT_SCREWED_UP) std::cout << "yeah it was AUDCLNT_E_UNSUPPORTED_FORMAT\n"; \
  std::cout << "Error: " << hr << "\n"; goto error; \
}

static int CmdLineSecs;
static int CmsLineOpenClose;
static int CmdLineStartStop;

static DWORD WINAPI ThreadProcMT(
  _In_ LPVOID lpParameter
)
{
   int count = (int)lpParameter;
   std::cout << "threaded open/close run# " << count << "\n";
   int res = RunOne(count);
   if(res != 0)
   {
     std::cout << "error\n";
     return res;
   }
   if(count>1)
     WaitForSingleObject(CreateThread(nullptr, 0, &ThreadProcMT, (void*)(count-1), 0, nullptr), INFINITE);
   return 0;
}

static DWORD WINAPI ThreadProcOVERLAP(
  _In_ LPVOID lpParameter
)
{
  int current = (int)lpParameter;
  std::cout << "overlapped open/close run# " << current << "\n";
  int res = RunOne(current);
  if (res != 0)
  {
    std::cout << "error\n";
    return res;
  }
  return res;
}

int main(int argc, char** argv)
{
  if(argc!= 5)
  {
    std::cout << " error , usage: me.exe MODE OPEN_CLOSE_count START_STOP_count REC_seconds\n";
    return 1;
  }
  CmsLineOpenClose = atoi(argv[2]);
  if (CmsLineOpenClose < 1)
  {
    std::cout << "error CmsLineOpenClose > 0" << "\n";
    return 1;
  }
  CmdLineStartStop = atoi(argv[3]);
  if (CmdLineStartStop < 1)
  {
    std::cout << "error CmdLineStartStop > 0" << "\n";
    return 1;
  }
  CmdLineSecs = atoi(argv[4]);
  if (CmdLineSecs<0 || CmdLineSecs>MAX_RECORD_SECONDS)
  {
    std::cout << "error recording length from 0 to " << MAX_RECORD_SECONDS << "\n";
    return 1;
  }
  if(!strcmp("-loop", argv[1]))
  {
    int run;
    for(int i = 0; i < CmsLineOpenClose; i++)
    {
      std::cout << "open/close run# " << i << "\n";
      run = RunOne(i);
      if(run!=0) return run;
    }
    return run;
  }
  if(!strcmp("-mt", argv[1]))
  {
    WaitForSingleObject(CreateThread(nullptr, 0, &ThreadProcMT, (void*)(10), 0, nullptr), INFINITE);
  }
  if (!strcmp("-overlap", argv[1]))
  {
    HANDLE threads [10];
    for(int i = 0; i < 10; i++)
      threads[i] = CreateThread(nullptr, 0, &ThreadProcOVERLAP, (void*)(i), 0, nullptr);
    WaitForMultipleObjects(10, threads, true, INFINITE);
  }
  return 0;  
}

int RunOne(int current)
{
  DWORD flags;
  HANDLE event;
  BYTE* buffer;
  UINT32 locked;
  UINT32 padding;
  UINT64 devicePos;
  UINT64 counterPos;
  UINT32 renderBufferSize;
  UINT32 captureBufferSize;
  CComPtr<IMMDevice> device;
  CComPtr<IAudioClient> render;
  CComPtr<IAudioClient> capture;
  CComPtr<IMMDeviceEnumerator> enumerator;
  CComPtr<IAudioRenderClient> renderClient;
  CComPtr<IAudioCaptureClient> captureClient;
  std::ofstream out("out.raw", std::ios::out | std::ios::binary);

  WAVEFORMATEXTENSIBLE wfx;
  wfx.dwChannelMask = 0;
  wfx.SubFormat = KSDATAFORMAT_SUBTYPE_IEEE_FLOAT;
  wfx.Samples.wValidBitsPerSample = sizeof(float) * 8;
  wfx.Format.nChannels = CHANNELS;
  wfx.Format.wBitsPerSample = sizeof(float) * 8;
  wfx.Format.nSamplesPerSec = SAMPLE_RATE;
  wfx.Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
  wfx.Format.cbSize = sizeof(WAVEFORMATEXTENSIBLE);
  wfx.Format.nBlockAlign = wfx.Format.wBitsPerSample / 8 * wfx.Format.nChannels;
  wfx.Format.nAvgBytesPerSec = wfx.Format.nSamplesPerSec * wfx.Format.nBlockAlign;

  event = CreateEvent(nullptr, FALSE, FALSE, nullptr);
  assert(event != nullptr);

  VERIFY(CoInitializeEx(0, COINIT_MULTITHREADED));
  VERIFY(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL,
    __uuidof(IMMDeviceEnumerator), reinterpret_cast<void**>(&enumerator)));
  VERIFY(enumerator->GetDefaultAudioEndpoint(eRender, eMultimedia, &device));

  VERIFY(device->Activate(__uuidof(IAudioClient), CLSCTX_ALL,
    nullptr, reinterpret_cast<void**>(&render)));
  VERIFY(render->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_EVENTCALLBACK,
    BUFFER_SIZE_HNS, 0, reinterpret_cast<WAVEFORMATEX*>(&wfx), nullptr));
  VERIFY(render->SetEventHandle(event));
  VERIFY(render->GetBufferSize(&renderBufferSize));
  VERIFY(render->GetService(__uuidof(IAudioRenderClient),
    reinterpret_cast<void**>(&renderClient)));

  VERIFY(device->Activate(__uuidof(IAudioClient), CLSCTX_ALL,
    nullptr, reinterpret_cast<void**>(&capture)));
  VERIFY(capture->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_LOOPBACK,
    BUFFER_SIZE_HNS, 0, reinterpret_cast<WAVEFORMATEX*>(&wfx), nullptr));
  VERIFY(capture->GetBufferSize(&captureBufferSize));
  VERIFY(capture->GetService(__uuidof(IAudioCaptureClient),
    reinterpret_cast<void**>(&captureClient)));

  for(int i = 0; i < CmdLineStartStop; i++)
  {
    std::cout << "\t open/close run " << current << "  start/stop run " << i << " of " << CmdLineStartStop << "\n";
    VERIFY(render->Start());
    VERIFY(capture->Start());
 

    int recorded = 0;
    while (recorded < CmdLineSecs * SAMPLE_RATE)
    {
      VERIFY(render->GetCurrentPadding(&padding));
      locked = renderBufferSize - padding;
      VERIFY(renderClient->GetBuffer(locked, &buffer));
      memset(buffer, 0, locked * CHANNELS * sizeof(float));
      VERIFY(renderClient->ReleaseBuffer(locked, 0));

      VERIFY(captureClient->GetBuffer(&buffer, &locked, &flags, &devicePos, &counterPos));
      for (UINT32 i = 0; i < locked; i++)
      {
        RECORDING[recorded * 2] = reinterpret_cast<float*>(buffer)[i * 2];
        RECORDING[recorded * 2 + 1] = reinterpret_cast<float*>(buffer)[i * 2 + 1];
        recorded++;
      }
      VERIFY(captureClient->ReleaseBuffer(locked));
    }

    VERIFY(capture->Stop());
    VERIFY(render->Stop());
  }

  out.write(reinterpret_cast<char*>(RECORDING), sizeof(float) * SAMPLE_RATE * CHANNELS * CmdLineSecs);
  CloseHandle(event);
  CoUninitialize();
  return 0;
error:
  CloseHandle(event);
  CoUninitialize();
  return 1;
}