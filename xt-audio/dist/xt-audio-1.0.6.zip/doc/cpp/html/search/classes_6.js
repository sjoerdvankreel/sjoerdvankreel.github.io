var searchData=
[
  ['latency',['Latency',['../struct_xt_1_1_latency.html',1,'Xt']]]
];
