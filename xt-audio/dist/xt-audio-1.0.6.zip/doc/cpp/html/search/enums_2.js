var searchData=
[
  ['sample',['Sample',['../namespace_xt.html#a426d1959db0f41f3a026d6c2cabf6cc5',1,'Xt']]],
  ['setup',['Setup',['../namespace_xt.html#ab9933484782935ad9201e8de8dc115e2',1,'Xt']]],
  ['system',['System',['../namespace_xt.html#a9cdc6635130ea35e68230bafb00ad6f3',1,'Xt']]]
];
