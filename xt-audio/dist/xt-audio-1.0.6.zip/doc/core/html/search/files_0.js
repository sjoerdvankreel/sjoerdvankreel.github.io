var searchData=
[
  ['core_2edox',['core.dox',['../core_8dox.html',1,'']]]
];
