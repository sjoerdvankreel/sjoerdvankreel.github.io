var searchData=
[
  ['bootstrapping_20interface',['Bootstrapping interface',['../group__audio.html',1,'']]]
];
