var searchData=
[
  ['rate',['rate',['../struct_xt_mix.html#ab731ec549b0aaea4dcb9a9f1dcc78fd9',1,'XtMix']]]
];
