var searchData=
[
  ['xtattributes',['XtAttributes',['../struct_xt_attributes.html',1,'']]],
  ['xtbuffer',['XtBuffer',['../struct_xt_buffer.html',1,'']]],
  ['xtchannels',['XtChannels',['../struct_xt_channels.html',1,'']]],
  ['xtformat',['XtFormat',['../struct_xt_format.html',1,'']]],
  ['xtlatency',['XtLatency',['../struct_xt_latency.html',1,'']]],
  ['xtmix',['XtMix',['../struct_xt_mix.html',1,'']]]
];
