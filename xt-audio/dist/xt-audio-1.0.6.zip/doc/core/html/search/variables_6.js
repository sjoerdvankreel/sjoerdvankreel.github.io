var searchData=
[
  ['xtfalse',['XtFalse',['../group__library.html#ga3e7928e19b69d5de4e72d9db16c0356e',1,'xt-audio.h']]],
  ['xttrue',['XtTrue',['../group__library.html#gac1d343c72c21839031abd3281176b9ed',1,'xt-audio.h']]]
];
