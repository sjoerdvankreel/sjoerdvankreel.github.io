var searchData=
[
  ['generic_20interface',['Generic interface',['../group__library.html',1,'']]]
];
