var indexSectionsWithContent =
{
  0: "bcdgimoprsx",
  1: "x",
  2: "cx",
  3: "x",
  4: "cimorsx",
  5: "x",
  6: "x",
  7: "x",
  8: "bdgps",
  9: "x"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

