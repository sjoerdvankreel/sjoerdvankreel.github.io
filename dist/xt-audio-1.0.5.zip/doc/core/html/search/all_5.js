var searchData=
[
  ['max',['max',['../struct_xt_buffer.html#a49021ae3f92c299f3b5b3d6e3985daa0',1,'XtBuffer']]],
  ['min',['min',['../struct_xt_buffer.html#af998d0c2755b85333562023af9dde3df',1,'XtBuffer']]],
  ['mix',['mix',['../struct_xt_format.html#aacd6535f397069e2cd8c69ba6f69aea3',1,'XtFormat']]]
];
