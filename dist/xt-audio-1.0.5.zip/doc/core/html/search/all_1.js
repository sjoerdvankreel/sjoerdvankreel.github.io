var searchData=
[
  ['core_2edox',['core.dox',['../core_8dox.html',1,'']]],
  ['current',['current',['../struct_xt_buffer.html#a7e4ee117e40297f21075c0feb9117a71',1,'XtBuffer']]]
];
