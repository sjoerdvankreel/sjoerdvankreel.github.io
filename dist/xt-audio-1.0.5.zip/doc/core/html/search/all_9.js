var searchData=
[
  ['sample',['sample',['../struct_xt_mix.html#a5c2fefdc26eced576454cc02559420cb',1,'XtMix']]],
  ['service_20interface',['Service interface',['../group__service.html',1,'']]],
  ['size',['size',['../struct_xt_attributes.html#a00a500264af79bd769f046ead1aff4d8',1,'XtAttributes']]],
  ['stream_20interface',['Stream interface',['../group__stream.html',1,'']]]
];
