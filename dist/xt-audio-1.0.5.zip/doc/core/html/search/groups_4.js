var searchData=
[
  ['service_20interface',['Service interface',['../group__service.html',1,'']]],
  ['stream_20interface',['Stream interface',['../group__stream.html',1,'']]]
];
