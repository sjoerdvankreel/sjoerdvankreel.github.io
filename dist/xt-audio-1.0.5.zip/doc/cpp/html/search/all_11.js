var searchData=
[
  ['wasapi',['Wasapi',['../namespace_xt.html#a9cdc6635130ea35e68230bafb00ad6f3ae0056fbfaeed1f67b0ab983ff74429bd',1,'Xt']]],
  ['what',['what',['../class_xt_1_1_exception.html#a6b5d408e63f6c4992e375cabe9f197bb',1,'Xt::Exception']]]
];
