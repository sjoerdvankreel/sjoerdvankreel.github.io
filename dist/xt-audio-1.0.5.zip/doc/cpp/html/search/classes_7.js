var searchData=
[
  ['mix',['Mix',['../struct_xt_1_1_mix.html',1,'Xt']]]
];
