var searchData=
[
  ['endpoint',['Endpoint',['../namespace_xt.html#a7f2325b43891508770e6029d5dd3e705a2a6ba72e93aa7fa676d07973ed2716bb',1,'Xt']]],
  ['error',['Error',['../namespace_xt.html#a9a57c9b56917d1dc62d1a845c4ad4599a902b0d55fddef6f8d651fe1035b7d4bd',1,'Xt']]]
];
