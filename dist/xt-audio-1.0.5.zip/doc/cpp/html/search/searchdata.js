var indexSectionsWithContent =
{
  0: "abcdefgijlmoprstuwx~",
  1: "abcdeflmps",
  2: "x",
  3: "x",
  4: "abcefgilmosw~",
  5: "cimors",
  6: "fstx",
  7: "cls",
  8: "acdefgijpsuw",
  9: "ads"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends"
};

