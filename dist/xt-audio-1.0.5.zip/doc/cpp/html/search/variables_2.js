var searchData=
[
  ['max',['max',['../struct_xt_1_1_buffer.html#a870c9b7e2811d0bd52ad244a74b9ba2f',1,'Xt::Buffer']]],
  ['min',['min',['../struct_xt_1_1_buffer.html#a770f76df168b6d8d0069f24e89d5e451',1,'Xt::Buffer']]],
  ['mix',['mix',['../struct_xt_1_1_format.html#a45c70617fa8590cf54a7bc99072b023c',1,'Xt::Format']]]
];
