var searchData=
[
  ['buffer',['Buffer',['../struct_xt_1_1_buffer.html',1,'Xt']]]
];
