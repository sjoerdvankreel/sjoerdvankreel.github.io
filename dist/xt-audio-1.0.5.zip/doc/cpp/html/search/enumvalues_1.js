var searchData=
[
  ['capabilitieschannelmask',['CapabilitiesChannelMask',['../namespace_xt.html#a14931080695b223f86014bca45b4a564a3cdbf5d849bf210f41b501420d130290',1,'Xt']]],
  ['capabilitiesfullduplex',['CapabilitiesFullDuplex',['../namespace_xt.html#a14931080695b223f86014bca45b4a564abf1fc1690c745095d3ce55c573bd345f',1,'Xt']]],
  ['capabilitieslatency',['CapabilitiesLatency',['../namespace_xt.html#a14931080695b223f86014bca45b4a564a7417c325fe7e5c39b0165a896d18d337',1,'Xt']]],
  ['capabilitiesnone',['CapabilitiesNone',['../namespace_xt.html#a14931080695b223f86014bca45b4a564adc63dab7b57b15ae32e339a1f5872017',1,'Xt']]],
  ['capabilitiestime',['CapabilitiesTime',['../namespace_xt.html#a14931080695b223f86014bca45b4a564ae569386d054d87dd6ade299d96036d65',1,'Xt']]],
  ['capabilitiesxrundetection',['CapabilitiesXRunDetection',['../namespace_xt.html#a14931080695b223f86014bca45b4a564a1f2934c2d6d960497e1a0893e15cce0b',1,'Xt']]],
  ['consumeraudio',['ConsumerAudio',['../namespace_xt.html#ab9933484782935ad9201e8de8dc115e2aebe729dd4e0fb3c6a05765c34100818f',1,'Xt']]]
];
