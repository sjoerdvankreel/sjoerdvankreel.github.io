var searchData=
[
  ['wasapi',['Wasapi',['../namespace_xt.html#a9cdc6635130ea35e68230bafb00ad6f3ae0056fbfaeed1f67b0ab983ff74429bd',1,'Xt']]]
];
