var searchData=
[
  ['isinterleaved',['IsInterleaved',['../class_xt_1_1_stream.html#ad15740c0fe69630ff66f42b6baf9239c',1,'Xt::Stream']]],
  ['iswin32',['IsWin32',['../class_xt_1_1_audio.html#aa38427e5f0f9b439789ead348d4a7aa5',1,'Xt::Audio']]]
];
