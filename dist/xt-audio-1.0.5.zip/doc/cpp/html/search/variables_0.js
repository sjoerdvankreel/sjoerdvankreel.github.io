var searchData=
[
  ['current',['current',['../struct_xt_1_1_buffer.html#acb747e447d0765f5fb94c6dd00f5dd76',1,'Xt::Buffer']]]
];
