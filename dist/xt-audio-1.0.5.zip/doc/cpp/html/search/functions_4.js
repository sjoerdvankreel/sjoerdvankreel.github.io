var searchData=
[
  ['format',['Format',['../struct_xt_1_1_format.html#aff064429a7e823b928ee1bcc08dec27d',1,'Xt::Format::Format()=default'],['../struct_xt_1_1_format.html#a20588fcdae534b392c1fd9215ae375ba',1,'Xt::Format::Format(const Mix &amp;mix, int32_t inputs, uint64_t inMask, int32_t outputs, uint64_t outMask)']]],
  ['formattostring',['FormatToString',['../class_xt_1_1_print.html#a82033c50262e83498fbca07fcdde8c9f',1,'Xt::Print']]]
];
